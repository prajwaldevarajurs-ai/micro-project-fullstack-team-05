from django.contrib import admin
from .models import Exam

admin.site.register(Exam)
